// Yogi Nugraha
// 247006111067
// C
// Tugas Praktikum 5 PBO

package Prak5.Tugas;

public class InvalidJumlahPenarikanException extends Exception {
    public InvalidJumlahPenarikanException(String message) {
        super(message);
    }
}
