// Yogi Nugraha
// 247006111067
// C
// Tugas Praktikum 5 PBO

package Prak5.Tugas;

public class InvalidPinException extends Exception {
    public InvalidPinException(String message) {
        super(message);
    }
}

